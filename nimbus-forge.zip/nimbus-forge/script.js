// Year in footer
document.getElementById('year').textContent = new Date().getFullYear();

// ---------- Hero chat demo ----------
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const script = [
  { from: 'user', text: 'Do you have anything available this Saturday afternoon?' },
  { from: 'agent', text: 'Yes — 2:00 PM and 4:30 PM are open Saturday. Want me to book one?' },
  { from: 'user', text: 'Yes, 4:30 please.' },
  { from: 'agent', text: "You're set for Saturday, 4:30 PM. I've sent a confirmation to your email." }
];

const chatLog = document.getElementById('chatLog');

function addBubble(from, text){
  const b = document.createElement('div');
  b.className = 'bubble bubble--' + from;
  b.textContent = text;
  chatLog.appendChild(b);
  while (chatLog.children.length > 5) chatLog.removeChild(chatLog.firstChild);
}

function addTyping(){
  const t = document.createElement('div');
  t.className = 'bubble bubble--agent bubble--typing';
  t.innerHTML = '<span></span><span></span><span></span>';
  chatLog.appendChild(t);
  return t;
}

async function playScript(){
  chatLog.innerHTML = '';
  for (const line of script){
    if (reduceMotion){
      addBubble(line.from, line.text);
      continue;
    }
    if (line.from === 'agent'){
      const typing = addTyping();
      await wait(900);
      typing.remove();
    } else {
      await wait(600);
    }
    addBubble(line.from, line.text);
    await wait(400);
  }
}

function wait(ms){ return new Promise(r => setTimeout(r, ms)); }

async function loopDemo(){
  await playScript();
  if (!reduceMotion){
    await wait(2600);
    loopDemo();
  }
}
loopDemo();

// ---------- Scroll reveal ----------
const revealTargets = document.querySelectorAll('.card, .work-card, .price-card, .process__step');
revealTargets.forEach(el => el.classList.add('reveal'));

if ('IntersectionObserver' in window){
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        entry.target.classList.add('is-visible');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  revealTargets.forEach(el => io.observe(el));
} else {
  revealTargets.forEach(el => el.classList.add('is-visible'));
}

// ---------- Contact form (static placeholder) ----------
const form = document.getElementById('contactForm');
const status = document.getElementById('formStatus');
form.addEventListener('submit', (e) => {
  e.preventDefault();
  status.textContent = "This form isn't connected yet — see the note above to wire it up.";
});
